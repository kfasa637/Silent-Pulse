# Silent Pulse

Android Kotlin + C++17 NDK companion overlay with a native Dear ImGui interface.

## Build

- Android Gradle Plugin: 8.1.0
- Kotlin: 1.8.10
- Gradle: 8.2
- JDK: 17
- NDK: 25.2.9519653
- CMake: 3.22.1

Open the folder in Android Studio and build `:app:assembleDebug`, or push to GitHub to run `.github/workflows/build.yml`.

Dear ImGui v1.90.9 is fetched by CMake during the native build, so the build environment needs network access.

## Run

1. Install the debug APK.
2. Open Silent Pulse.
3. Tap **START SILENT PULSE OVERLAY** and grant Android's display-over-other-apps permission.
4. Tap the button again. The native ImGui panel appears as a movable floating window.
5. Use **LAUNCH MINECRAFT** to open the installed Minecraft app.

## Scope

This project is a companion UI and local rendering demo. The Combat/Visuals/Cosmetics/Misc controls are preview state only. It does not inject into Minecraft, inspect or modify its process memory, alter game packets, or bypass anti-cheat.
