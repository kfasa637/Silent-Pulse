# Keep JNI bridge names stable.
-keep class com.silentpulse.NativeBridge { *; }
