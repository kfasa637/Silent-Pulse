#include <jni.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>

#include <atomic>
#include <chrono>
#include <mutex>
#include <thread>
#include <vector>

#include "imgui.h"
#include "imgui_impl_opengl3.h"
#include "cheats.h"

#define SP_LOGI(...) __android_log_print(ANDROID_LOG_INFO, "SilentPulse", __VA_ARGS__)
#define SP_LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "SilentPulse", __VA_ARGS__)

namespace {
struct TouchEvent {
    int action;
    float x;
    float y;
};

std::atomic<bool> gRunning{false};
std::thread gRenderThread;
std::mutex gInputMutex;
std::vector<TouchEvent> gTouchQueue;

void ApplyTheme() {
    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 12.0f;
    style.FrameRounding = 6.0f;
    style.GrabRounding = 6.0f;
    style.ScrollbarRounding = 8.0f;
    style.WindowBorderSize = 1.0f;
    style.FrameBorderSize = 0.0f;
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.071f, 0.071f, 0.071f, 0.97f);
    style.Colors[ImGuiCol_ChildBg] = ImVec4(0.055f, 0.075f, 0.075f, 1.0f);
    style.Colors[ImGuiCol_Border] = ImVec4(0.0f, 0.72f, 0.58f, 0.75f);
    style.Colors[ImGuiCol_Text] = ImVec4(0.0f, 1.0f, 0.80f, 1.0f);
    style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.35f, 0.58f, 0.54f, 1.0f);
    style.Colors[ImGuiCol_Button] = ImVec4(0.0f, 0.32f, 0.27f, 1.0f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.0f, 0.58f, 0.46f, 1.0f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.0f, 0.78f, 0.62f, 1.0f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.0f, 1.0f, 0.80f, 1.0f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.10f, 0.13f, 0.13f, 1.0f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.0f, 0.28f, 0.23f, 1.0f);
    style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.0f, 0.85f, 0.68f, 1.0f);
}

void DrawMenu() {
    static int activeTab = 0;
    ImGui::SetNextWindowSize(ImVec2(370.0f, 520.0f), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowBgAlpha(0.97f);

    if (ImGui::Begin("SILENT PULSE  //  BEDROCK COMPANION")) {
        ImGui::TextDisabled("NATIVE PANEL  •  BUILD 1.0.0");
        ImGui::Separator();

        const char* tabs[] = {"Combat", "Visuals", "Cosmetics", "Misc"};
        for (int i = 0; i < 4; ++i) {
            if (i > 0) ImGui::SameLine();
            if (activeTab == i) {
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.0f, 0.55f, 0.45f, 1.0f));
            }
            if (ImGui::Button(tabs[i], ImVec2(82.0f, 32.0f))) activeTab = i;
            if (activeTab == i) ImGui::PopStyleColor();
        }
        ImGui::Spacing();
        ImGui::BeginChild("tab_content", ImVec2(0, 0), true);
        switch (activeTab) {
            case 0: SilentPulse::DrawCombatTab(); break;
            case 1: SilentPulse::DrawVisualsTab(); break;
            case 2: SilentPulse::DrawCosmeticsTab(); break;
            default: SilentPulse::DrawMiscTab(); break;
        }
        ImGui::EndChild();
    }
    ImGui::End();
}

void RenderLoop(ANativeWindow* window) {
    EGLDisplay display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display == EGL_NO_DISPLAY) {
        SP_LOGE("eglGetDisplay failed");
        ANativeWindow_release(window);
        gRunning = false;
        return;
    }

    EGLint major = 0, minor = 0;
    if (!eglInitialize(display, &major, &minor)) {
        SP_LOGE("eglInitialize failed");
        ANativeWindow_release(window);
        gRunning = false;
        return;
    }

    const EGLint configAttributes[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
        EGL_NONE
    };
    EGLConfig config{};
    EGLint configCount = 0;
    if (!eglChooseConfig(display, configAttributes, &config, 1, &configCount) || configCount == 0) {
        SP_LOGE("No compatible EGL config");
        eglTerminate(display);
        ANativeWindow_release(window);
        gRunning = false;
        return;
    }

    const EGLint contextAttributes[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    EGLContext context = eglCreateContext(display, config, EGL_NO_CONTEXT, contextAttributes);
    EGLSurface surface = eglCreateWindowSurface(display, config, window, nullptr);
    if (context == EGL_NO_CONTEXT || surface == EGL_NO_SURFACE ||
        !eglMakeCurrent(display, surface, surface, context)) {
        SP_LOGE("Failed to create EGL context/surface");
        if (surface != EGL_NO_SURFACE) eglDestroySurface(display, surface);
        if (context != EGL_NO_CONTEXT) eglDestroyContext(display, context);
        eglTerminate(display);
        ANativeWindow_release(window);
        gRunning = false;
        return;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.DisplaySize = ImVec2(
        static_cast<float>(ANativeWindow_getWidth(window)),
        static_cast<float>(ANativeWindow_getHeight(window))
    );
    ApplyTheme();
    ImGui_ImplOpenGL3_Init("#version 300 es");

    while (gRunning.load()) {
        {
            std::lock_guard<std::mutex> lock(gInputMutex);
            for (const TouchEvent& event : gTouchQueue) {
                if (event.action == 0) {
                    io.AddMousePosEvent(event.x, event.y);
                    io.AddMouseButtonEvent(0, true);
                } else if (event.action == 1 || event.action == 3) {
                    io.AddMousePosEvent(event.x, event.y);
                    io.AddMouseButtonEvent(0, false);
                } else if (event.action == 2) {
                    io.AddMousePosEvent(event.x, event.y);
                }
            }
            gTouchQueue.clear();
        }

        const int width = ANativeWindow_getWidth(window);
        const int height = ANativeWindow_getHeight(window);
        io.DisplaySize = ImVec2(static_cast<float>(width), static_cast<float>(height));
        glViewport(0, 0, width, height);
        glClearColor(0.035f, 0.045f, 0.045f, 0.96f);
        glClear(GL_COLOR_BUFFER_BIT);

        ImGui_ImplOpenGL3_NewFrame();
        ImGui::NewFrame();
        DrawMenu();
        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        eglSwapBuffers(display, surface);
        std::this_thread::sleep_for(std::chrono::milliseconds(16));
    }

    ImGui_ImplOpenGL3_Shutdown();
    ImGui::DestroyContext();
    eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    eglDestroySurface(display, surface);
    eglDestroyContext(display, context);
    eglTerminate(display);
    ANativeWindow_release(window);
    SP_LOGI("Native overlay renderer stopped");
}
} // namespace

extern "C" JNIEXPORT void JNICALL
Java_com_silentpulse_NativeBridge_nativeStart(JNIEnv* env, jobject /* thiz */, jobject javaSurface) {
    if (gRunning.load()) return;

    ANativeWindow* window = ANativeWindow_fromSurface(env, javaSurface);
    if (window == nullptr) {
        SP_LOGE("ANativeWindow_fromSurface returned null");
        return;
    }

    gRunning = true;
    gRenderThread = std::thread(RenderLoop, window);
}

extern "C" JNIEXPORT void JNICALL
Java_com_silentpulse_NativeBridge_nativeStop(JNIEnv* /* env */, jobject /* thiz */) {
    gRunning = false;
    if (gRenderThread.joinable()) gRenderThread.join();
}

extern "C" JNIEXPORT void JNICALL
Java_com_silentpulse_NativeBridge_nativeTouch(
    JNIEnv* /* env */, jobject /* thiz */, jint action, jfloat x, jfloat y) {
    std::lock_guard<std::mutex> lock(gInputMutex);
    gTouchQueue.push_back({static_cast<int>(action), x, y});
}
