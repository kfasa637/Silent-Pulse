#pragma once

#include "imgui.h"

namespace SilentPulse {

// This is UI/demo state only. It deliberately has no game-process access,
// memory editing, packet manipulation, or anti-cheat bypass implementation.
struct FeatureState {
    bool aimAssistPreview = false;
    bool reachPreview = false;
    bool hitboxPreview = false;
    bool velocityPreview = false;
    bool triggerPreview = false;
    bool autoClickerPreview = false;

    bool playerEspDemo = true;
    bool chestEspDemo = false;
    bool tracersDemo = false;
    bool fullbrightPreview = false;
    bool damageTextDemo = false;
    bool smoothZoomDemo = false;

    bool wingsPreview = false;
    bool capePreview = false;
    bool haloPreview = false;
    bool jumpCirclePreview = false;
    bool trailsPreview = false;

    bool hitSoundPreview = false;
    bool blockSoundPreview = false;
    bool hurtSoundPreview = false;
    bool cameraModePreview = false;
    bool compactMode = false;
};

inline FeatureState gFeatures;

inline void DrawCombatTab() {
    ImGui::TextDisabled("LOCAL CONTROL PRESETS");
    ImGui::Separator();
    ImGui::Checkbox("Aim Assist (UI preview)", &gFeatures.aimAssistPreview);
    ImGui::Checkbox("Reach indicator (UI preview)", &gFeatures.reachPreview);
    ImGui::Checkbox("Hitbox indicator (UI preview)", &gFeatures.hitboxPreview);
    ImGui::Checkbox("Velocity indicator (UI preview)", &gFeatures.velocityPreview);
    ImGui::Checkbox("TriggerBot panel preview", &gFeatures.triggerPreview);
    ImGui::Checkbox("AutoClicker panel preview", &gFeatures.autoClickerPreview);
    ImGui::Spacing();
    ImGui::TextWrapped("These switches only change this companion panel. They do not affect Minecraft combat.");
}

inline void DrawVisualsTab() {
    ImGui::TextDisabled("SANDBOX VISUAL PREVIEW");
    ImGui::Separator();
    ImGui::Checkbox("Player ESP demo", &gFeatures.playerEspDemo);
    ImGui::Checkbox("Chest ESP demo", &gFeatures.chestEspDemo);
    ImGui::Checkbox("Tracers demo", &gFeatures.tracersDemo);
    ImGui::Checkbox("Fullbright preset (preview)", &gFeatures.fullbrightPreview);
    ImGui::Checkbox("Damage text demo", &gFeatures.damageTextDemo);
    ImGui::Checkbox("Smooth zoom preset", &gFeatures.smoothZoomDemo);

    ImGui::Spacing();
    ImGui::Text("Preview canvas");
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImVec2 size(300.0f, 145.0f);
    ImDrawList* draw = ImGui::GetWindowDrawList();
    draw->AddRectFilled(p, ImVec2(p.x + size.x, p.y + size.y), IM_COL32(8, 20, 22, 255), 8.0f);
    draw->AddRect(p, ImVec2(p.x + size.x, p.y + size.y), IM_COL32(0, 255, 204, 150), 8.0f);
    if (gFeatures.playerEspDemo) {
        draw->AddRect(ImVec2(p.x + 112, p.y + 25), ImVec2(p.x + 160, p.y + 118),
                      IM_COL32(0, 255, 204, 255), 2.0f);
        draw->AddText(ImVec2(p.x + 108, p.y + 8), IM_COL32(0, 255, 204, 255), "PLAYER");
    }
    if (gFeatures.chestEspDemo) {
        draw->AddRect(ImVec2(p.x + 220, p.y + 72), ImVec2(p.x + 260, p.y + 110),
                      IM_COL32(255, 190, 70, 255), 2.0f);
        draw->AddText(ImVec2(p.x + 215, p.y + 54), IM_COL32(255, 190, 70, 255), "CHEST");
    }
    if (gFeatures.tracersDemo) {
        draw->AddLine(ImVec2(p.x + 150, p.y + 140), ImVec2(p.x + 136, p.y + 120),
                      IM_COL32(0, 255, 204, 255), 2.0f);
    }
    ImGui::Dummy(size);
}

inline void DrawCosmeticsTab() {
    ImGui::TextDisabled("COSMETIC PREVIEW");
    ImGui::Separator();
    ImGui::Checkbox("3D Wings preview", &gFeatures.wingsPreview);
    ImGui::Checkbox("Cape preview", &gFeatures.capePreview);
    ImGui::Checkbox("Halo preview", &gFeatures.haloPreview);
    ImGui::Checkbox("Jump circle preview", &gFeatures.jumpCirclePreview);
    ImGui::Checkbox("Trails preview", &gFeatures.trailsPreview);
    ImGui::Spacing();
    ImGui::TextWrapped("Cosmetic switches are local showcase controls. No player model or game assets are modified.");
}

inline void DrawMiscTab() {
    ImGui::TextDisabled("COMPANION SETTINGS");
    ImGui::Separator();
    ImGui::Checkbox("Hit sound preview enabled", &gFeatures.hitSoundPreview);
    ImGui::Checkbox("Block sound preview enabled", &gFeatures.blockSoundPreview);
    ImGui::Checkbox("Hurt sound preview enabled", &gFeatures.hurtSoundPreview);
    ImGui::Checkbox("Compact panel", &gFeatures.compactMode);
    ImGui::Spacing();
    if (ImGui::Button("F5  /  Toggle camera demo", ImVec2(-1, 38))) {
        gFeatures.cameraModePreview = !gFeatures.cameraModePreview;
    }
    ImGui::Text("Camera demo: %s", gFeatures.cameraModePreview ? "THIRD-PERSON PREVIEW" : "DEFAULT PREVIEW");
    ImGui::TextWrapped("F5 changes the companion's preview state only; it does not write to Minecraft memory.");
}

} // namespace SilentPulse
