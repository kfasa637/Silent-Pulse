package com.silentpulse

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.Toast

class MainActivity : Activity() {
    private val accent = Color.rgb(0, 255, 204)
    private val background = Color.rgb(18, 18, 18)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(36), dp(24), dp(24))
            setBackgroundColor(background)
        }

        val title = TextView(this).apply {
            text = "SILENT PULSE"
            textSize = 28f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setTextColor(accent)
            letterSpacing = 0.12f
        }

        val subtitle = TextView(this).apply {
            text = "BEDROCK COMPANION  •  NATIVE OVERLAY"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            letterSpacing = 0.08f
            setPadding(0, dp(8), 0, dp(36))
        }

        val launch = makeButton("LAUNCH MINECRAFT")
        launch.setOnClickListener { launchMinecraft() }

        val overlay = makeButton("START SILENT PULSE OVERLAY")
        overlay.setOnClickListener { startOverlay() }

        val stop = makeButton("STOP OVERLAY")
        stop.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Overlay stopped", Toast.LENGTH_SHORT).show()
        }

        val note = TextView(this).apply {
            text = "Native ImGui control panel. Features shown in this build are local UI previews and do not modify Minecraft or its memory."
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(28), dp(8), 0)
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(launch, matchWidth())
        root.addView(overlay, matchWidth())
        root.addView(stop, matchWidth())
        root.addView(note, matchWidth())
        setContentView(root)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "Allow display over other apps, then tap Start again.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, OverlayService::class.java)
        startForegroundService(intent)
        Toast.makeText(this, "Silent Pulse overlay started", Toast.LENGTH_SHORT).show()
    }

    private fun launchMinecraft() {
        val launchIntent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (launchIntent == null) {
            Toast.makeText(this, "Minecraft was not found on this device.", Toast.LENGTH_LONG).show()
            return
        }
        startActivity(launchIntent)
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.BLACK)
        setBackgroundColor(accent)
        isAllCaps = false
        setPadding(dp(12), dp(8), dp(12), dp(8))
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        dp(54)
    ).apply {
        bottomMargin = dp(12)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
