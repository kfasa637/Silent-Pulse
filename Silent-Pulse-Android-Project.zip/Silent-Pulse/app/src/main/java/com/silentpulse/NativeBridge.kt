package com.silentpulse

import android.view.Surface

object NativeBridge {
    init {
        System.loadLibrary("SilentPulse")
    }

    external fun nativeStart(surface: Surface)
    external fun nativeStop()
    external fun nativeTouch(action: Int, x: Float, y: Float)
}
