package com.silentpulse

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout

class OverlayService : Service(), SurfaceHolder.Callback {
    private lateinit var windowManager: WindowManager
    private var overlayRoot: FrameLayout? = null
    private var surfaceView: SurfaceView? = null
    private var nativeStarted = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        attachOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun attachOverlay() {
        if (overlayRoot != null) return

        val density = resources.displayMetrics.density
        val surface = SurfaceView(this).apply {
            setZOrderOnTop(false)
            holder.setFormat(PixelFormat.OPAQUE)
            holder.addCallback(this@OverlayService)
            setOnTouchListener { _, event ->
                if (nativeStarted) {
                    val action = when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> 0
                        MotionEvent.ACTION_UP -> 1
                        MotionEvent.ACTION_MOVE -> 2
                        MotionEvent.ACTION_CANCEL -> 3
                        else -> -1
                    }
                    if (action >= 0) NativeBridge.nativeTouch(action, event.x, event.y)
                }
                true
            }
        }

        val root = FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            addView(
                surface,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            (390 * density).toInt(),
            (560 * density).toInt(),
            type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = (12 * density).toInt()
            y = (72 * density).toInt()
        }

        windowManager.addView(root, params)
        overlayRoot = root
        surfaceView = surface
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        NativeBridge.nativeStart(holder.surface)
        nativeStarted = true
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        if (nativeStarted) {
            NativeBridge.nativeStop()
            nativeStarted = false
        }
    }

    override fun onDestroy() {
        if (nativeStarted) {
            NativeBridge.nativeStop()
            nativeStarted = false
        }
        overlayRoot?.let {
            if (it.isAttachedToWindow) windowManager.removeView(it)
        }
        overlayRoot = null
        surfaceView = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Silent Pulse overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("Silent Pulse is running")
            .setContentText("Native floating control panel is active.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "silent_pulse_overlay"
        private const val NOTIFICATION_ID = 4107
    }
}
